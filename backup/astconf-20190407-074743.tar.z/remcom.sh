#!/bin/sh

TARGET="extensions.conf extensions_inhouse.conf extensions_pickup.conf extensions_features.conf extensions_keysubsys.conf extensions_vm.conf extensions_fixedpark.conf extensions_macros.conf extensions_incoming.conf extensions_outgoing.conf"

DEST="./ncomment/"

for i in $TARGET
do
    grep -v '^;' $i | sed 's/NoOp\(.*\)/NoOp\(\)/' > $DEST/$i
done
