<?php
$hoge = file_get_contents("pjsip_wizard.conf");
$hoge = str_replace('(phone-defaults)', '', $hoge);
$hoge = str_replace('(!)', '', $hoge);
$hoge = parse_ini_string($hoge, true);
print_r($hoge);

for($i=1;$i<=32;$i++){
    echo $hoge["phone$i"]['inbound_auth/password'];
    echo "";
}
?>
