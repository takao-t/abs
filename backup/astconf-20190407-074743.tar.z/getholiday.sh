NKF="nkf -u"
D2U="dos2unix"
WGET="wget"
FILE="syukujitsu_kyujitsu.csv"
URL="http://www8.cao.go.jp/chosei/shukujitsu/syukujitsu_kyujitsu.csv"
TARGET="holidays.txt"

# Asterisk DB用
ASTDBFAM="HOLIDAYS/JAPAN"

# あったら削除しておく
rm -f $FILE

# 取得
$WGET $URL > /dev/null 2>&1

# UNIX形式に変換して漢字コードをUTFに
$D2U < $FILE | $NKF > $TARGET.tmp

# 見出し行削除
LNS=`wc -l $TARGET.tmp | cut -f1,1 -d' '`
LNS=`expr $LNS - 1`
tail -$LNS $TARGET.tmp > $TARGET

# 中間ファイル削除
rm -f $TARGET.tmp

